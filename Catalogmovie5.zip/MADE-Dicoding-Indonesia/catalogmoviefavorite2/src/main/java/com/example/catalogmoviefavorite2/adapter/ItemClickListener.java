package com.example.catalogmoviefavorite2.adapter;

import com.example.catalogmoviefavorite2.data.DataMovie;

public interface ItemClickListener {
    void onItemClick(DataMovie dataMovie);
}